"use client";

import { useState } from "react";
import type { FormEvent } from "react";
import type { ProjectDraft } from "@/types/drafts";

interface ProjectFormProps {
  initial?: ProjectDraft;
  submitLabel: string;
  isSubmitting: boolean;
  onSubmit: (draft: ProjectDraft) => void;
  onCancel?: () => void;
}

const INPUT_CLASS = "mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm";

export function ProjectForm({ initial, submitLabel, isSubmitting, onSubmit, onCancel }: ProjectFormProps) {
  const [name, setName] = useState(initial?.name ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!name.trim()) return;
    onSubmit({ name: name.trim(), description: description.trim() });
    if (!initial) {
      setName("");
      setDescription("");
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3 rounded-lg border border-slate-200 bg-white p-4">
      <label className="block text-sm">
        Project name
        <input required value={name} onChange={(event) => setName(event.target.value)} className={INPUT_CLASS} />
      </label>
      <label className="block text-sm">
        Description
        <textarea rows={2} value={description} onChange={(event) => setDescription(event.target.value)} className={INPUT_CLASS} />
      </label>
      <div className="flex gap-2">
        <button type="submit" disabled={isSubmitting} className="rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50">
          {submitLabel}
        </button>
        {onCancel && (
          <button type="button" onClick={onCancel} className="rounded-md border border-slate-300 px-4 py-2 text-sm">
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
