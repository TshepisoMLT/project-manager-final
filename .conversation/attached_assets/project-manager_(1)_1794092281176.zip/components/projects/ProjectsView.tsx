"use client";

import Link from "next/link";
import { useState } from "react";
import { useDashboard } from "@/hooks/useDashboard";
import { useCreateProject } from "@/hooks/useProjectActions";
import { useResetData } from "@/hooks/useResetData";
import { Pager } from "@/components/ui/Pagination";
import { ProgressBar } from "./ProgressBar";
import { ProjectForm } from "./ProjectForm";

const PROJECTS_PER_PAGE = 6;

export function ProjectsView() {
  const { data, isLoading, isError } = useDashboard();
  const [isCreating, setIsCreating] = useState(false);
  const createProject = useCreateProject();
  const resetData = useResetData();
  const [page, setPage] = useState(0);

  if (isLoading) return <p role="status">Loading projects…</p>;
  if (isError || !data) {
    return <p role="alert" className="text-red-600">Could not load projects.</p>;
  }
  const pageCount = Math.ceil(data.progress.length / PROJECTS_PER_PAGE);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold">Projects</h1>
        <button
          type="button"
          onClick={() => setIsCreating((open) => !open)}
          className="rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white"
        >
          {isCreating ? "Close" : "New project"}
        </button>
      </div>
      {isCreating && (
        <ProjectForm
          submitLabel="Create project"
          isSubmitting={createProject.isPending}
          onSubmit={(draft) => createProject.mutate(draft, { onSuccess: () => setIsCreating(false) })}
        />
      )}
      {createProject.isError && <p role="alert" className="text-sm text-red-600">Could not create the project.</p>}
      {data.progress.length === 0 && <p>No projects yet.</p>}
      <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {data.progress.slice(page * PROJECTS_PER_PAGE, (page + 1) * PROJECTS_PER_PAGE).map(({ project, done, total, percent }) => (
          <li key={project.id}>
            <Link href={`/projects/${project.id}`} className="block rounded-lg border border-slate-200 bg-white p-4 hover:border-slate-400">
              <h2 className="font-semibold">
                {project.name}
                {project.archived && <span className="ml-2 rounded-full bg-slate-200 px-2 py-0.5 text-xs font-normal">Archived</span>}
              </h2>
              <p className="mt-1 text-sm text-slate-600">{project.description}</p>
              <p className="mb-1 mt-4 text-xs text-slate-600">{done} of {total} tasks done</p>
              <ProgressBar percent={percent} label={`${project.name} progress`} />
            </Link>
          </li>
        ))}
      </ul>
      <Pager page={page} pageCount={pageCount} onPageChange={setPage} />
      <button type="button" onClick={resetData} className="text-xs text-slate-600 underline">
        Reset sample data
      </button>
    </div>
  );
}
