const BUTTON_CLASS = "rounded-md border border-slate-300 bg-white px-3 py-1.5 text-sm disabled:opacity-50";

interface PagerProps {
  page: number;
  pageCount: number;
  onPageChange: (page: number) => void;
}

export function Pager({ page, pageCount, onPageChange }: PagerProps) {
  if (pageCount <= 1) return null;
  return (
    <nav aria-label="Pagination" className="flex items-center justify-between gap-3 text-sm">
      <button type="button" disabled={page === 0} onClick={() => onPageChange(page - 1)} className={BUTTON_CLASS}>
        Previous
      </button>
      <span className="text-slate-600">Page {page + 1} of {pageCount}</span>
      <button type="button" disabled={page >= pageCount - 1} onClick={() => onPageChange(page + 1)} className={BUTTON_CLASS}>
        Next
      </button>
    </nav>
  );
}

interface ShowMoreProps {
  shown: number;
  total: number;
  onShowMore: () => void;
}

export function ShowMore({ shown, total, onShowMore }: ShowMoreProps) {
  if (shown >= total) return null;
  return (
    <button type="button" onClick={onShowMore} className={`mt-2 w-full ${BUTTON_CLASS}`}>
      Show more ({total - shown} left)
    </button>
  );
}
