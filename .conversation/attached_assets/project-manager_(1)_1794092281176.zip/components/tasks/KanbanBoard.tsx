"use client";

import { useState } from "react";
import { ShowMore } from "@/components/ui/Pagination";
import { useUiStore } from "@/stores/ui";
import { STATUS_LABELS, TASK_STATUSES } from "@/types";
import type { Task, TaskPriority, TaskStatus } from "@/types";
import { TaskCard } from "./TaskCard";
import { TaskFilters } from "./TaskFilters";

const STEP = 10;
const PRIORITY_RANK: Record<TaskPriority, number> = { high: 0, medium: 1, low: 2 };

interface KanbanBoardProps {
  tasks: Task[];
  onMove: (id: string, status: TaskStatus) => void;
}

export function KanbanBoard({ tasks, onMove }: KanbanBoardProps) {
  const filters = useUiStore((state) => state.taskFilters);
  const [visible, setVisible] = useState<Record<TaskStatus, number>>({
    todo: STEP,
    in_progress: STEP,
    review: STEP,
    done: STEP,
  });
  const today = new Date().toISOString().slice(0, 10);
  const assignees = Array.from(new Set(tasks.map((task) => task.assignee))).sort();

  const shown = tasks
    .filter((task) => filters.priority === "all" || task.priority === filters.priority)
    .filter((task) => filters.assignee === "all" || task.assignee === filters.assignee)
    .sort((a, b) =>
      filters.sort === "priority"
        ? PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority] || a.dueDate.localeCompare(b.dueDate)
        : a.dueDate.localeCompare(b.dueDate),
    );

  return (
    <div className="space-y-4">
      <TaskFilters assignees={assignees} />
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {TASK_STATUSES.map((status) => {
          const column = shown.filter((task) => task.status === status);
          return (
            <section key={status} aria-label={STATUS_LABELS[status]} className="rounded-lg bg-slate-100 p-3">
              <h2 className="mb-3 text-sm font-semibold">
                {STATUS_LABELS[status]} <span className="font-normal text-slate-500">({column.length})</span>
              </h2>
              {column.length === 0 && <p className="text-sm text-slate-500">No tasks</p>}
              <ul className="space-y-2">
                {column.slice(0, visible[status]).map((task) => {
                  const isOverdue = task.status !== "done" && task.dueDate < today;
                  return (
                    <li key={task.id} className={isOverdue ? "rounded-md ring-2 ring-red-400" : undefined}>
                      {isOverdue && <p className="rounded-t-md bg-red-100 px-3 py-1 text-xs font-medium text-red-800">Overdue</p>}
                      <TaskCard task={task} onMove={onMove} />
                    </li>
                  );
                })}
              </ul>
              <ShowMore
                shown={visible[status]}
                total={column.length}
                onShowMore={() => setVisible((current) => ({ ...current, [status]: current[status] + STEP }))}
              />
            </section>
          );
        })}
      </div>
    </div>
  );
}
