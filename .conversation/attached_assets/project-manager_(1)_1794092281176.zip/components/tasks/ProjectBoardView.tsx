"use client";

import Link from "next/link";
import { useState } from "react";
import { useProject } from "@/hooks/useProjects";
import { useUpdateProject } from "@/hooks/useProjectActions";
import { useCreateTask, useMoveTask, useTasks } from "@/hooks/useTasks";
import { ProjectForm } from "@/components/projects/ProjectForm";
import { KanbanBoard } from "./KanbanBoard";
import { NewTaskForm } from "./NewTaskForm";

interface ProjectBoardViewProps {
  projectId: string;
}

export function ProjectBoardView({ projectId }: ProjectBoardViewProps) {
  const project = useProject(projectId);
  const tasks = useTasks(projectId);
  const moveTask = useMoveTask();
  const createTask = useCreateTask();
  const updateProject = useUpdateProject();
  const [isEditing, setIsEditing] = useState(false);

  if (project.isLoading || tasks.isLoading) return <p role="status">Loading project…</p>;
  if (project.isError || tasks.isError) {
    return <p role="alert" className="text-red-600">Could not load this project.</p>;
  }
  const current = project.data;
  if (!current) {
    return (
      <div className="space-y-2">
        <p>Project not found.</p>
        <Link href="/projects" className="text-sm underline">Back to projects</Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <Link href="/projects" className="text-sm text-slate-600 underline">All projects</Link>
        {isEditing ? (
          <ProjectForm
            initial={{ name: current.name, description: current.description }}
            submitLabel="Save"
            isSubmitting={updateProject.isPending}
            onSubmit={(draft) => updateProject.mutate({ id: projectId, changes: draft }, { onSuccess: () => setIsEditing(false) })}
            onCancel={() => setIsEditing(false)}
          />
        ) : (
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="text-2xl font-semibold">
                {current.name}
                {current.archived && <span className="ml-2 rounded-full bg-slate-200 px-2 py-0.5 text-xs font-normal">Archived</span>}
              </h1>
              <p className="text-sm text-slate-600">{current.description}</p>
            </div>
            <div className="flex gap-2">
              <button type="button" onClick={() => setIsEditing(true)} className="rounded-md border border-slate-300 px-3 py-1.5 text-sm">
                Edit
              </button>
              <button
                type="button"
                disabled={updateProject.isPending}
                onClick={() => updateProject.mutate({ id: projectId, changes: { archived: !current.archived } })}
                className="rounded-md border border-slate-300 px-3 py-1.5 text-sm disabled:opacity-50"
              >
                {current.archived ? "Restore" : "Archive"}
              </button>
            </div>
          </div>
        )}
      </div>
      <NewTaskForm isSubmitting={createTask.isPending} onSubmit={(draft) => createTask.mutate({ ...draft, projectId })} />
      {(createTask.isError || moveTask.isError || updateProject.isError) && (
        <p role="alert" className="text-sm text-red-600">Something went wrong saving changes. Please try again.</p>
      )}
      <KanbanBoard tasks={tasks.data ?? []} onMove={(id, status) => moveTask.mutate({ id, status })} />
    </div>
  );
}
