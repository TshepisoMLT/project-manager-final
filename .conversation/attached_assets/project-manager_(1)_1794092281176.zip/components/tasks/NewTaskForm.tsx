"use client";

import { useState } from "react";
import type { FormEvent } from "react";
import type { TaskPriority } from "@/types";
import type { TaskDraft } from "@/types/drafts";

interface NewTaskFormProps {
  isSubmitting: boolean;
  onSubmit: (draft: TaskDraft) => void;
  initial?: TaskDraft;
  submitLabel?: string;
  onCancel?: () => void;
}

const INPUT_CLASS = "mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm";
const CREATE_LAYOUT = "grid gap-3 rounded-lg border border-slate-200 bg-white p-4 sm:grid-cols-2 lg:grid-cols-5";
const EDIT_LAYOUT = "space-y-3 rounded-md border border-slate-300 bg-white p-3";

export function NewTaskForm({ isSubmitting, onSubmit, initial, submitLabel = "Add task", onCancel }: NewTaskFormProps) {
  const [title, setTitle] = useState(initial?.title ?? "");
  const [assignee, setAssignee] = useState(initial?.assignee ?? "");
  const [dueDate, setDueDate] = useState(initial?.dueDate ?? "");
  const [priority, setPriority] = useState<TaskPriority>(initial?.priority ?? "medium");

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!title.trim() || !dueDate) return;
    onSubmit({ title: title.trim(), assignee: assignee.trim() || "Unassigned", dueDate, priority });
    if (!initial) {
      setTitle("");
      setAssignee("");
    }
  }

  return (
    <form onSubmit={handleSubmit} className={initial ? EDIT_LAYOUT : CREATE_LAYOUT}>
      <label className="block text-sm sm:col-span-2">
        Task title
        <input required value={title} onChange={(event) => setTitle(event.target.value)} className={INPUT_CLASS} />
      </label>
      <label className="block text-sm">
        Assignee
        <input value={assignee} onChange={(event) => setAssignee(event.target.value)} className={INPUT_CLASS} />
      </label>
      <label className="block text-sm">
        Due date
        <input type="date" required value={dueDate} onChange={(event) => setDueDate(event.target.value)} className={INPUT_CLASS} />
      </label>
      <label className="block text-sm">
        Priority
        <select value={priority} onChange={(event) => setPriority(event.target.value as TaskPriority)} className={INPUT_CLASS}>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
      </label>
      <div className="flex gap-2 sm:col-span-2 lg:col-span-5">
        <button type="submit" disabled={isSubmitting} className="flex-1 rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50">
          {submitLabel}
        </button>
        {onCancel && (
          <button type="button" onClick={onCancel} className="rounded-md border border-slate-300 px-4 py-2 text-sm">
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
