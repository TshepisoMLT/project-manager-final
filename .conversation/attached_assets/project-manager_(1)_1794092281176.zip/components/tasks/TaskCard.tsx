"use client";

import { useState } from "react";
import { useDeleteTask, useUpdateTask } from "@/hooks/useTaskActions";
import { STATUS_LABELS, TASK_STATUSES } from "@/types";
import type { Task, TaskPriority, TaskStatus } from "@/types";
import { NewTaskForm } from "./NewTaskForm";

const PRIORITY_STYLES: Record<TaskPriority, string> = {
  low: "bg-slate-200 text-slate-700",
  medium: "bg-amber-100 text-amber-800",
  high: "bg-red-100 text-red-800",
};

interface TaskCardProps {
  task: Task;
  onMove: (id: string, status: TaskStatus) => void;
}

export function TaskCard({ task, onMove }: TaskCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const updateTask = useUpdateTask();
  const deleteTask = useDeleteTask();
  const selectId = `move-${task.id}`;

  if (isEditing) {
    return (
      <NewTaskForm
        initial={{ title: task.title, assignee: task.assignee, dueDate: task.dueDate, priority: task.priority }}
        submitLabel="Save"
        isSubmitting={updateTask.isPending}
        onSubmit={(draft) => updateTask.mutate({ id: task.id, draft }, { onSuccess: () => setIsEditing(false) })}
        onCancel={() => setIsEditing(false)}
      />
    );
  }

  return (
    <article className="rounded-md border border-slate-200 bg-white p-3 shadow-sm">
      <h3 className="text-sm font-medium">{task.title}</h3>
      <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-600">
        <span className={`rounded-full px-2 py-0.5 font-medium ${PRIORITY_STYLES[task.priority]}`}>{task.priority}</span>
        <span>{task.assignee}</span>
        <span>Due {task.dueDate}</span>
      </div>
      <label htmlFor={selectId} className="mt-3 block text-xs text-slate-600">Move to</label>
      <select
        id={selectId}
        value={task.status}
        onChange={(event) => onMove(task.id, event.target.value as TaskStatus)}
        className="mt-1 w-full rounded-md border border-slate-300 bg-white px-2 py-1.5 text-sm"
      >
        {TASK_STATUSES.map((status) => (
          <option key={status} value={status}>{STATUS_LABELS[status]}</option>
        ))}
      </select>
      <div className="mt-3 flex gap-3 text-xs">
        <button type="button" onClick={() => setIsEditing(true)} className="font-medium underline">Edit</button>
        <button
          type="button"
          disabled={deleteTask.isPending}
          onClick={() => {
            if (window.confirm("Delete this task?")) deleteTask.mutate(task.id);
          }}
          className="font-medium text-red-700 underline disabled:opacity-50"
        >
          Delete
        </button>
      </div>
      {deleteTask.isError && <p role="alert" className="mt-2 text-xs text-red-600">Could not delete this task.</p>}
    </article>
  );
}
