"use client";

import { useUiStore } from "@/stores/ui";
import type { TaskSort } from "@/stores/ui";
import type { TaskPriority } from "@/types";

interface TaskFiltersProps {
  assignees: string[];
}

const SELECT_CLASS = "mt-1 block rounded-md border border-slate-300 bg-white px-2 py-1.5 text-sm";

export function TaskFilters({ assignees }: TaskFiltersProps) {
  const filters = useUiStore((state) => state.taskFilters);
  const setTaskFilters = useUiStore((state) => state.setTaskFilters);

  return (
    <div className="flex flex-wrap gap-3">
      <label className="text-xs text-slate-600">
        Priority
        <select
          value={filters.priority}
          onChange={(event) => setTaskFilters({ priority: event.target.value as TaskPriority | "all" })}
          className={SELECT_CLASS}
        >
          <option value="all">All</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
      </label>
      <label className="text-xs text-slate-600">
        Assignee
        <select value={filters.assignee} onChange={(event) => setTaskFilters({ assignee: event.target.value })} className={SELECT_CLASS}>
          <option value="all">Everyone</option>
          {assignees.map((name) => (
            <option key={name} value={name}>{name}</option>
          ))}
        </select>
      </label>
      <label className="text-xs text-slate-600">
        Sort by
        <select value={filters.sort} onChange={(event) => setTaskFilters({ sort: event.target.value as TaskSort })} className={SELECT_CLASS}>
          <option value="due">Due date</option>
          <option value="priority">Priority</option>
        </select>
      </label>
    </div>
  );
}
