"use client";

import Link from "next/link";
import { useDashboard } from "@/hooks/useDashboard";
import { ProgressBar } from "@/components/projects/ProgressBar";

interface StatCardProps {
  label: string;
  value: number;
}

function StatCard({ label, value }: StatCardProps) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white p-4">
      <p className="text-sm text-slate-600">{label}</p>
      <p className="mt-1 text-2xl font-semibold">{value}</p>
    </div>
  );
}

export function DashboardView() {
  const { data, isLoading, isError } = useDashboard();

  if (isLoading) return <p role="status">Loading dashboard…</p>;
  if (isError || !data) {
    return <p role="alert" className="text-red-600">Could not load the dashboard.</p>;
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Dashboard</h1>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Active projects" value={data.activeProjects} />
        <StatCard label="Completed tasks" value={data.completedTasks} />
        <StatCard label="Overdue tasks" value={data.overdue} />
        <StatCard label="Upcoming deadlines" value={data.upcoming.length} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <section aria-labelledby="progress-heading" className="rounded-lg border border-slate-200 bg-white p-4">
          <h2 id="progress-heading" className="mb-3 font-semibold">Project progress</h2>
          <ul className="space-y-4">
            {data.progress.map(({ project, done, total, percent }) => (
              <li key={project.id}>
                <Link href={`/projects/${project.id}`} className="text-sm font-medium underline">{project.name}</Link>
                <p className="mb-1 text-xs text-slate-600">{done} of {total} tasks done</p>
                <ProgressBar percent={percent} label={`${project.name} progress`} />
              </li>
            ))}
          </ul>
        </section>
        <section aria-labelledby="upcoming-heading" className="rounded-lg border border-slate-200 bg-white p-4">
          <h2 id="upcoming-heading" className="mb-3 font-semibold">Upcoming deadlines</h2>
          {data.upcoming.length === 0 && <p className="text-sm text-slate-600">No upcoming deadlines.</p>}
          <ul className="space-y-2">
            {data.upcoming.map((task) => (
              <li key={task.id} className="flex justify-between gap-3 text-sm">
                <Link href={`/projects/${task.projectId}`} className="underline">{task.title}</Link>
                <span className="shrink-0 text-slate-600">{task.dueDate}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
