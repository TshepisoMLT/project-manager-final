"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import type { FormEvent } from "react";

type AuthMode = "login" | "register" | "reset";

interface AuthFormProps {
  mode: AuthMode;
}

interface AuthCopy {
  title: string;
  subtitle: string;
  submit: string;
}

const COPY: Record<AuthMode, AuthCopy> = {
  login: { title: "Welcome back", subtitle: "Log in to manage your projects.", submit: "Log in" },
  register: { title: "Create your account", subtitle: "Start managing tasks in minutes.", submit: "Create account" },
  reset: { title: "Reset your password", subtitle: "Enter your email and we will send you a reset link.", submit: "Send reset link" },
};

const INPUT_CLASS = "mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm";
const LINK_CLASS = "font-medium text-slate-900 underline";

export function AuthForm({ mode }: AuthFormProps) {
  const router = useRouter();
  const [isSent, setIsSent] = useState(false);
  const copy = COPY[mode];

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (mode === "reset") {
      setIsSent(true);
      return;
    }
    router.push("/dashboard");
  }

  return (
    <div className="w-full max-w-sm space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">{copy.title}</h1>
        <p className="mt-1 text-sm text-slate-600">{copy.subtitle}</p>
      </div>
      <p className="rounded-md bg-amber-50 px-3 py-2 text-xs text-amber-800">
        Preview only: accounts and sign-in are not connected yet.
      </p>
      {isSent ? (
        <p role="status" className="rounded-md bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
          If an account exists for that email, a reset link is on its way.
        </p>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "register" && (
            <label className="block text-sm">
              Full name
              <input required autoComplete="name" className={INPUT_CLASS} />
            </label>
          )}
          <label className="block text-sm">
            Email
            <input type="email" required autoComplete="email" className={INPUT_CLASS} />
          </label>
          {mode !== "reset" && (
            <label className="block text-sm">
              Password
              <input
                type="password"
                required
                minLength={8}
                autoComplete={mode === "login" ? "current-password" : "new-password"}
                className={INPUT_CLASS}
              />
            </label>
          )}
          <button type="submit" className="w-full rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white">
            {copy.submit}
          </button>
        </form>
      )}
      <nav aria-label="Account links" className="flex flex-col gap-1 text-sm text-slate-600">
        {mode === "login" && (
          <>
            <Link href="/register" className={LINK_CLASS}>Create an account</Link>
            <Link href="/reset-password" className={LINK_CLASS}>Forgot your password?</Link>
          </>
        )}
        {mode === "register" && <Link href="/login" className={LINK_CLASS}>Already have an account? Log in</Link>}
        {mode === "reset" && <Link href="/login" className={LINK_CLASS}>Back to log in</Link>}
      </nav>
    </div>
  );
}
