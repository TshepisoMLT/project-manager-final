"use client";

import Link from "next/link";
import { useState } from "react";
import { useSearch } from "@/hooks/useSearch";
import { ShowMore } from "@/components/ui/Pagination";
import { STATUS_LABELS } from "@/types";

const STEP = 10;

export function SearchView() {
  const [query, setQuery] = useState("");
  const [projectLimit, setProjectLimit] = useState(STEP);
  const [taskLimit, setTaskLimit] = useState(STEP);
  const { results, isLoading, isError } = useSearch(query);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Search</h1>
      <label className="block text-sm">
        Search projects, tasks, or assignees
        <input
          type="search"
          value={query}
          onChange={(event) => {
            setQuery(event.target.value);
            setProjectLimit(STEP);
            setTaskLimit(STEP);
          }}
          className="mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
        />
      </label>
      {isLoading && <p role="status">Loading…</p>}
      {isError && <p role="alert" className="text-red-600">Could not load search data.</p>}
      {results && results.projects.length === 0 && results.tasks.length === 0 && (
        <p className="text-sm text-slate-600">No matches.</p>
      )}
      {results && results.projects.length > 0 && (
        <section aria-labelledby="search-projects">
          <h2 id="search-projects" className="mb-2 font-semibold">Projects</h2>
          <ul className="space-y-2 text-sm">
            {results.projects.slice(0, projectLimit).map((project) => (
              <li key={project.id}>
                <Link href={`/projects/${project.id}`} className="underline">{project.name}</Link>
              </li>
            ))}
          </ul>
          <ShowMore shown={projectLimit} total={results.projects.length} onShowMore={() => setProjectLimit((n) => n + STEP)} />
        </section>
      )}
      {results && results.tasks.length > 0 && (
        <section aria-labelledby="search-tasks">
          <h2 id="search-tasks" className="mb-2 font-semibold">Tasks</h2>
          <ul className="space-y-2 text-sm">
            {results.tasks.slice(0, taskLimit).map((task) => (
              <li key={task.id}>
                <Link href={`/projects/${task.projectId}`} className="underline">{task.title}</Link>
                <span className="text-slate-600"> · {task.assignee} · {STATUS_LABELS[task.status]}</span>
              </li>
            ))}
          </ul>
          <ShowMore shown={taskLimit} total={results.tasks.length} onShowMore={() => setTaskLimit((n) => n + STEP)} />
        </section>
      )}
    </div>
  );
}
