# Architecture

Layer flow (no layer is skipped):

```text
UI (components/) -> Hooks (hooks/) -> Services (services/) -> data source
```

The data source is currently **in-memory sample data**. Supabase has not been connected yet.

## Folders

| Folder | Responsibility |
| --- | --- |
| `app/` | Routing, layouts, providers |
| `components/` | Presentation (`auth/`, `dashboard/`, `layout/`, `projects/`, `search/`, `tasks/`) |
| `hooks/` | Data fetching and behaviour (TanStack Query) |
| `services/` | All data access, one file per domain (`projects.ts`, `tasks.ts`) |
| `stores/` | Client state only (Zustand) |
| `types/` | Shared interfaces (`index.ts`, `drafts.ts`) |

## Routes

| Route | Screen | Notes |
| --- | --- | --- |
| `/` | Redirect to `/login` | |
| `/login`, `/register`, `/reset-password` | Auth screens | Visual only. No authentication happens |
| `/dashboard` | Dashboard | Active projects, completed and overdue tasks, progress, upcoming deadlines |
| `/projects` | Project list | Create projects |
| `/projects/[projectId]` | Kanban board | Edit and archive the project; create, edit, delete, and move tasks |
| `/search` | Search | Projects, tasks, assignees |

Route groups: `(auth)` for the auth screens, `(app)` for screens inside the app shell.

## State

- **Server state** (projects, tasks): TanStack Query. The provider lives in `app/providers.tsx`. Moving a task updates the cache optimistically.
- **Client state**: Zustand. `stores/ui.ts` holds the mobile sidebar state and the Kanban filters and sort.
- Database entities are never stored in Zustand.

## Data layer

`services/projects.ts` and `services/tasks.ts` keep arrays in memory, seeded with sample data, and simulate latency. Data is saved to the browser's local storage after every change (`services/storage.ts`) and falls back to the seed data if storage is empty, blocked, or corrupt. A "Reset sample data" button on the Projects page clears it. Data is per browser and is not shared. Hooks call these services and never touch the arrays directly, so replacing the service internals with Supabase queries should not require UI changes.

## Board and list behaviour

- The Kanban board can be filtered by priority and assignee and sorted by due date or priority. Overdue tasks that are not done get a red outline and an "Overdue" tag.
- Pagination is display-level only: the Projects page shows 6 per page, and each board column and search list shows 10 with a "Show more" button. It becomes server-side pagination when Supabase is added.

## Not implemented yet

- Supabase, real authentication, protected routes, and Row Level Security
- Realtime subscriptions (these will live in `hooks/`)
- Drag-and-drop on the Kanban board (tasks move through the "Move to" menu)
- Member management and roles
