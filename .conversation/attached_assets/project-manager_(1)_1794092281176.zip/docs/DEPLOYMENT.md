# Deployment

Hosting: Vercel (Next.js is auto-detected). Project name: `project-manager`.

## Build

```bash
npm install
npm run lint
npm run build
```

## Deploying

Current deployments were uploaded directly to Vercel as production builds. To deploy on every push instead:

1. Push this repository to GitHub.
2. In Vercel, open the `project-manager` project, go to Settings, then Git, and connect the repository.
3. Every push to the production branch will then build and deploy automatically.

## Environment variables

None are required at the moment. The app runs on in-memory sample data.

| Variable | Used from | Notes |
| --- | --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase phase | Not used yet |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase phase | Not used yet |

Set variables in the Vercel project settings. Never commit `.env` files or the service-role key.

## Known limitations

- Sign-in is visual only, so every screen is publicly reachable.
- Data is saved in each visitor's browser only and is not shared between users or devices.
