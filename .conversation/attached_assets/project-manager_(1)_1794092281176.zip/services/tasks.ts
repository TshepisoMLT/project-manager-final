import type { NewTaskInput, Task, TaskStatus } from "@/types";
import type { TaskDraft } from "@/types/drafts";
import { simulateLatency } from "./latency";
import { loadOrSeed, saveList } from "./storage";

function dayOffset(days: number): string {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString().slice(0, 10);
}

const tasks: Task[] = loadOrSeed("tasks", [
  { id: "t1", projectId: "p1", title: "Audit current pages", status: "done", priority: "medium", assignee: "Amara", dueDate: dayOffset(-6) },
  { id: "t2", projectId: "p1", title: "Design new homepage", status: "in_progress", priority: "high", assignee: "Lebo", dueDate: dayOffset(2) },
  { id: "t3", projectId: "p1", title: "Write case study copy", status: "todo", priority: "low", assignee: "Sam", dueDate: dayOffset(-1) },
  { id: "t4", projectId: "p1", title: "Review mobile layouts", status: "review", priority: "medium", assignee: "Amara", dueDate: dayOffset(4) },
  { id: "t5", projectId: "p2", title: "Set up store listings", status: "todo", priority: "medium", assignee: "Sam", dueDate: dayOffset(9) },
  { id: "t6", projectId: "p2", title: "Fix onboarding crash", status: "in_progress", priority: "high", assignee: "Lebo", dueDate: dayOffset(1) },
  { id: "t7", projectId: "p2", title: "Run beta feedback round", status: "done", priority: "low", assignee: "Amara", dueDate: dayOffset(-3) },
  { id: "t8", projectId: "p3", title: "Draft welcome checklist", status: "todo", priority: "medium", assignee: "Sam", dueDate: dayOffset(6) },
  { id: "t9", projectId: "p3", title: "Record walkthrough video", status: "review", priority: "low", assignee: "Lebo", dueDate: dayOffset(3) },
]);

export async function listTasks(projectId?: string): Promise<Task[]> {
  await simulateLatency();
  return tasks
    .filter((task) => !projectId || task.projectId === projectId)
    .map((task) => ({ ...task }));
}

export async function createTask(input: NewTaskInput): Promise<Task> {
  await simulateLatency();
  const task: Task = { ...input, id: `t${Date.now()}`, status: "todo" };
  tasks.push(task);
  saveList("tasks", tasks);
  return { ...task };
}

export async function updateTaskStatus(id: string, status: TaskStatus): Promise<void> {
  await simulateLatency();
  const task = tasks.find((item) => item.id === id);
  if (!task) throw new Error("Task not found");
  task.status = status;
  saveList("tasks", tasks);
}

export async function updateTask(id: string, draft: TaskDraft): Promise<void> {
  await simulateLatency();
  const task = tasks.find((item) => item.id === id);
  if (!task) throw new Error("Task not found");
  Object.assign(task, draft);
  saveList("tasks", tasks);
}

export async function deleteTask(id: string): Promise<void> {
  await simulateLatency();
  const index = tasks.findIndex((item) => item.id === id);
  if (index === -1) throw new Error("Task not found");
  tasks.splice(index, 1);
  saveList("tasks", tasks);
}
