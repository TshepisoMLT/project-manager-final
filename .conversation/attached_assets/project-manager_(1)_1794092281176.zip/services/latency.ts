export function simulateLatency(): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, 150));
}
