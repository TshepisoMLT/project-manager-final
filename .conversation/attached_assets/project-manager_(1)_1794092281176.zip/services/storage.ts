const PREFIX = "pm.";
const KEYS = ["projects", "tasks"];

export function loadOrSeed<T>(key: string, seed: T[]): T[] {
  if (typeof window === "undefined") return seed;
  try {
    const raw = window.localStorage.getItem(PREFIX + key);
    const parsed: unknown = raw ? JSON.parse(raw) : null;
    return Array.isArray(parsed) ? (parsed as T[]) : seed;
  } catch {
    return seed;
  }
}

export function saveList<T>(key: string, list: T[]): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(PREFIX + key, JSON.stringify(list));
  } catch {
    // Storage is full or blocked: keep working in memory only.
  }
}

export function clearSavedData(): void {
  if (typeof window === "undefined") return;
  try {
    KEYS.forEach((key) => window.localStorage.removeItem(PREFIX + key));
  } catch {
    // Storage is blocked: nothing to clear.
  }
}
