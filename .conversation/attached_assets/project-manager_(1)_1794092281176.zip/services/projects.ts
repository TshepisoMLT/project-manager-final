import type { Project } from "@/types";
import type { ProjectDraft } from "@/types/drafts";
import { simulateLatency } from "./latency";
import { loadOrSeed, saveList } from "./storage";

const projects: Project[] = loadOrSeed("projects", [
  { id: "p1", name: "Website Redesign", description: "Refresh the marketing site for the new brand.", archived: false },
  { id: "p2", name: "Mobile App Launch", description: "Ship version 1 of the iOS and Android apps.", archived: false },
  { id: "p3", name: "Client Onboarding", description: "Standardise onboarding for new agency clients.", archived: false },
]);

export async function listProjects(): Promise<Project[]> {
  await simulateLatency();
  return projects.map((project) => ({ ...project }));
}

export async function getProject(id: string): Promise<Project | null> {
  await simulateLatency();
  const found = projects.find((project) => project.id === id);
  return found ? { ...found } : null;
}

export async function createProject(draft: ProjectDraft): Promise<Project> {
  await simulateLatency();
  const project: Project = { ...draft, id: `p${Date.now()}`, archived: false };
  projects.push(project);
  saveList("projects", projects);
  return { ...project };
}

export async function updateProject(id: string, changes: Partial<Omit<Project, "id">>): Promise<void> {
  await simulateLatency();
  const project = projects.find((item) => item.id === id);
  if (!project) throw new Error("Project not found");
  Object.assign(project, changes);
  saveList("projects", projects);
}
