# PROJECT_CONTEXT.md

# Project Context

This document exists to give AI coding assistants complete context about the project.

Every AI agent must read this file before making changes.

Related files:

- AGENTS.md
- CODE_STYLE.md
- ARCHITECTURE_RULES.md
- docs/PRD.md
- docs/ARCHITECTURE.md
- docs/DATABASE.md

If requirements conflict, use the following priority:

1. AGENTS.md
2. ARCHITECTURE_RULES.md
3. CODE_STYLE.md
4. PROJECT_CONTEXT.md
5. Other documentation

---

# Project Overview

Project Manager is a modern web application for project and task management.

It is designed for:

- Freelancers
- Small teams
- Startups
- Developers
- Agencies

The goal is to provide a clean, fast, collaborative experience without the complexity of enterprise tools.

The product should feel closer to Linear and Trello than Jira.

---

# Product Vision

Allow users to:

- Create projects
- Organise work
- Assign responsibility
- Track progress
- Collaborate in real time
- Monitor deadlines
- View project health at a glance

The user should be able to go from account creation to managing tasks in under five minutes.

---

# Core Product Principles

## Simplicity

Always choose the simpler solution.

Avoid:

- unnecessary abstraction
- unnecessary configuration
- unnecessary complexity

---

## Performance

The application should feel instant.

Prioritise:

- fast page loads
- cached data
- optimistic updates
- minimal re-renders

---

## Clarity

Every screen should have a single purpose.

Users should not need training to use the application.

---

## Mobile Friendly

Desktop is the primary experience.

Mobile support is required.

All new UI must work on:

- desktop
- tablet
- mobile

---

# Current Project Status

## Phase

UI prototype (sample data, no database)

---

## Completed

- Product vision defined
- MVP defined
- Architecture defined
- Database design defined
- Development standards defined
- Repository setup and Next.js foundation (deployed to Vercel)
- UI for auth screens (visual only), dashboard, projects, tasks, Kanban board, and search
- Sample data served through services/ and hooks/ (in memory)

---

## In Progress

None

---

## Not Started

- Supabase configuration
- Real authentication and route protection
- Database schema and Row Level Security
- Replacing the in-memory services with Supabase
- Realtime updates
- Drag-and-drop on the Kanban board
---

# MVP Scope

The first production version includes:

## Authentication

Users can:

- register
- login
- logout
- reset password

---

## Projects

Users can:

- create projects
- edit projects
- archive projects

---

## Tasks

Users can:

- create tasks
- edit tasks
- delete tasks
- assign tasks
- set due dates
- set priorities

---

## Kanban Board

Columns:

- To Do
- In Progress
- Review
- Done

Users can drag tasks between columns.

---

## Dashboard

Users can view:

- active projects
- completed tasks
- project progress
- overdue work
- upcoming deadlines

---

## Search

Search by:

- project
- task
- assignee

---

# Explicit Non-Goals

These features must NOT be included in the MVP.

## Not Included

- AI assistants
- Chat systems
- Messaging
- Video calls
- Time tracking
- Billing
- Invoicing
- CRM functionality
- Gantt charts
- File storage system
- Team workspaces
- Slack integration
- Microsoft Teams integration

These may be considered in future versions.

---

# User Roles

## Member

Can:

- view assigned projects
- create tasks
- update tasks

Cannot:

- manage project membership
- delete projects

---

## Admin

Can:

- manage projects
- invite members
- archive projects

---

## Owner

Can:

- perform all admin actions
- remove admins
- delete projects

---

# Tech Stack

## Frontend

- Next.js
- React
- TypeScript
- Tailwind CSS

---

## State

- Zustand
- TanStack Query

---

## Backend

- Supabase

Services used:

- PostgreSQL
- Authentication
- Realtime
- Storage

---

## Hosting

- Vercel

---

# Database Source of Truth

Primary tables:

```text
profiles
projects
project_members
tasks
```

Future tables may include:

```text
comments
attachments
activity_logs
notifications
```

Do not invent additional tables without updating documentation.

---

# Architecture Rules

Always follow this flow:

```text
UI
 ↓
Hooks
 ↓
Services
 ↓
Supabase
```

Never skip layers.

---

# State Management Rules

## TanStack Query

Use for:

- projects
- tasks
- members
- dashboard data

---

## Zustand

Use only for:

- sidebar state
- modal state
- filters
- theme
- local preferences

Never store database entities in Zustand.

---

# Security Requirements

All sensitive operations must be enforced by:

- Supabase Auth
- Row Level Security

Never rely on:

- hidden UI
- disabled buttons
- client-side checks

Client-side checks improve UX only.

Security always belongs in the database.

---

# Performance Goals

Target performance:

- Initial load < 3 seconds
- Page navigation feels instant
- Task updates appear immediately
- No full-page reloads during normal use

Use:

- pagination
- caching
- optimistic updates
- memoisation where appropriate

Avoid:

- N+1 queries
- duplicate fetching
- unnecessary state

---

# Realtime Strategy

Realtime is used for:

- task creation
- task updates
- task deletion

Realtime subscriptions belong in:

```text
hooks/
```

Never inside components.

---

# Documentation Requirements

Whenever any of these change:

- architecture
- database schema
- authentication flow
- environment variables

Documentation must also be updated.

Files:

- docs/ARCHITECTURE.md
- docs/DATABASE.md
- docs/DEPLOYMENT.md

---

# Current Priorities

Priority order:

1. Repository setup
2. Next.js foundation
3. Supabase setup
4. Authentication
5. Project management
6. Task management
7. Kanban board
8. Dashboard
9. Realtime updates

Work should always support the highest unfinished priority.

---

# Future Roadmap

Version 1.1

- comments
- activity feed
- notifications

Version 1.2

- file attachments
- project templates

Version 2.0

- AI task generation
- AI project insights
- advanced analytics

---

# Instructions For AI Agents

Before writing code:

1. Read AGENTS.md
2. Read CODE_STYLE.md
3. Read ARCHITECTURE_RULES.md
4. Read PROJECT_CONTEXT.md

Before implementing anything:

- verify it aligns with MVP goals
- verify it follows architecture rules
- verify it uses approved technologies

If uncertain:

STOP

Ask for clarification rather than making assumptions.
