# ARCHITECTURE_RULES.md

Mandatory architecture patterns.

---

# 1. Layer Architecture

UI

components/

↓

Hooks

hooks/

↓

Services

services/

↓

Supabase

No exceptions.

---

# 2. Data Flow

User Action

↓

Component

↓

Hook

↓

Service

↓

Database

↓

Query Cache

↓

UI Update

---

# 3. State Rules

Server State

Managed by:

TanStack Query

Examples:

- Projects
- Tasks
- Members

Never store server data in Zustand.

---

Client State

Managed by:

Zustand

Examples:

- Sidebar state
- Selected project
- Modal visibility
- Filters

Never store business data in Zustand.

---

# 4. Authentication

Protected routes:

/dashboard

/projects/*

/tasks/*

/settings

Unauthenticated users must be redirected.

---

# 5. Authorisation

Project membership controls access.

Users can only access:

- their own projects
- their own tasks
- projects they belong to

All enforcement must happen in RLS.

Never rely on frontend permissions.

---

# 6. Database Design Rules

Tables:

profiles

projects

project_members

tasks

Future tables:

comments

attachments

activity_logs

notifications

Do not add tables without updating DATABASE.md.

---

# 7. API Rules

Every domain gets a service.

Example:

services/projects.ts

services/tasks.ts

services/members.ts

No direct queries elsewhere.

---

# 8. Realtime

Use Supabase Realtime for:

- task creation
- task updates
- task deletion

Realtime subscriptions belong in hooks.

Never inside UI components.

---

# 9. Performance

Always:

- paginate lists
- lazy load pages
- memoise expensive computations

Avoid:

N+1 queries

Repeated fetches

Large client-side filtering

---

# 10. Future AI Features

When AI features are added:

Place them in:

services/ai/

Never mix AI prompts with UI code.

Every prompt must be version-controlled.
