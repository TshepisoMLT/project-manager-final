# CODE_STYLE.md

Project Manager code standards.

---

# 1. Stack

Frontend

- Next.js App Router
- React
- TypeScript
- Tailwind CSS

Backend

- Supabase

State

- Zustand
- TanStack Query

Hosting

- Vercel

---

# 2. TypeScript Rules

Strict mode must remain enabled.

Never use:

any

ts-ignore

ts-nocheck

Instead create proper types.

---

# 3. Naming

Variables

camelCase

Example:

projectName

Functions

camelCase

Example:

createTask

Components

PascalCase

Example:

TaskCard

Hooks

useSomething

Example:

useTasks

Interfaces

PascalCase

Example:

Task

Project

TaskCardProps

Constants

UPPER_SNAKE_CASE

Example:

MAX_TASKS

---

# 4. React Components

Use function components.

Good:

export function TaskCard() {}

Avoid:

React.FC

Class components

---

# 5. Component Size

Soft limit:

200 lines

When a component grows larger:

- Extract hooks
- Extract child components

Do not create giant files.

---

# 6. Styling

Use Tailwind only.

Avoid:

Inline styles

Avoid:

Custom CSS files unless absolutely necessary.

Prefer:

className

Example:

className="rounded-lg border bg-white"

---

# 7. Data Access

Never access Supabase directly inside UI components.

Bad:

TaskCard.tsx
→ supabase query

Good:

TaskCard
→ hook
→ service
→ Supabase

---

# 8. Error Handling

Every async action must handle:

- loading
- success
- error
- empty state

Never swallow errors.

---

# 9. Accessibility

Every interactive element must have:

- visible label
- keyboard support
- aria attributes when required

---

# 10. File Structure

app/

routing only

components/

presentation only

hooks/

data and behaviour

services/

database access

stores/

client state

types/

shared interfaces

Never mix responsibilities.
