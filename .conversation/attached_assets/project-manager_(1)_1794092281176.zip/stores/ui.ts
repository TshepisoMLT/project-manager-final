import { create } from "zustand";
import type { TaskPriority } from "@/types";

export type TaskSort = "due" | "priority";

export interface TaskFilters {
  priority: TaskPriority | "all";
  assignee: string;
  sort: TaskSort;
}

interface UiState {
  isSidebarOpen: boolean;
  taskFilters: TaskFilters;
  toggleSidebar: () => void;
  setSidebarOpen: (isOpen: boolean) => void;
  setTaskFilters: (changes: Partial<TaskFilters>) => void;
}

export const useUiStore = create<UiState>((set) => ({
  isSidebarOpen: false,
  taskFilters: { priority: "all", assignee: "all", sort: "due" },
  toggleSidebar: () => set((state) => ({ isSidebarOpen: !state.isSidebarOpen })),
  setSidebarOpen: (isOpen) => set({ isSidebarOpen: isOpen }),
  setTaskFilters: (changes) => set((state) => ({ taskFilters: { ...state.taskFilters, ...changes } })),
}));
