import type { NewTaskInput, Project } from "@/types";

export type TaskDraft = Omit<NewTaskInput, "projectId">;
export type ProjectDraft = Pick<Project, "name" | "description">;
