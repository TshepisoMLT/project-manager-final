import { ProjectBoardView } from "@/components/tasks/ProjectBoardView";

interface ProjectPageProps {
  params: Promise<{ projectId: string }>;
}

export default async function ProjectPage({ params }: ProjectPageProps) {
  const { projectId } = await params;
  return <ProjectBoardView projectId={projectId} />;
}
