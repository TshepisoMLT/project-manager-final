import { clearSavedData } from "@/services/storage";

export function useResetData() {
  return () => {
    clearSavedData();
    window.location.reload();
  };
}
