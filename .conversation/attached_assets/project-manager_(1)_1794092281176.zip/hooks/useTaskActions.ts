import { useMutation, useQueryClient } from "@tanstack/react-query";
import { deleteTask, updateTask } from "@/services/tasks";
import type { TaskDraft } from "@/types/drafts";

interface UpdateTaskInput {
  id: string;
  draft: TaskDraft;
}

export function useUpdateTask() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, draft }: UpdateTaskInput) => updateTask(id, draft),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tasks"] }),
  });
}

export function useDeleteTask() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => deleteTask(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tasks"] }),
  });
}
