import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createProject, updateProject } from "@/services/projects";
import type { Project } from "@/types";
import type { ProjectDraft } from "@/types/drafts";

export function useCreateProject() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (draft: ProjectDraft) => createProject(draft),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["projects"] }),
  });
}

interface UpdateProjectInput {
  id: string;
  changes: Partial<Omit<Project, "id">>;
}

export function useUpdateProject() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, changes }: UpdateProjectInput) => updateProject(id, changes),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["projects"] }),
  });
}
