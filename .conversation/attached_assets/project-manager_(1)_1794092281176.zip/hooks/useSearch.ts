import { useMemo } from "react";
import { useProjects } from "./useProjects";
import { useTasks } from "./useTasks";

export function useSearch(query: string) {
  const projects = useProjects();
  const tasks = useTasks();
  const projectList = projects.data;
  const taskList = tasks.data;
  const term = query.trim().toLowerCase();

  const results = useMemo(() => {
    if (!projectList || !taskList || !term) return null;
    return {
      projects: projectList.filter(
        (project) => project.name.toLowerCase().includes(term) || project.description.toLowerCase().includes(term),
      ),
      tasks: taskList.filter(
        (task) => task.title.toLowerCase().includes(term) || task.assignee.toLowerCase().includes(term),
      ),
    };
  }, [projectList, taskList, term]);

  return {
    results,
    isLoading: projects.isLoading || tasks.isLoading,
    isError: projects.isError || tasks.isError,
  };
}
