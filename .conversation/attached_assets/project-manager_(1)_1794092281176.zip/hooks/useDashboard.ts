import { useMemo } from "react";
import type { ProjectProgress } from "@/types";
import { useProjects } from "./useProjects";
import { useTasks } from "./useTasks";

export function useDashboard() {
  const projects = useProjects();
  const tasks = useTasks();
  const projectList = projects.data;
  const taskList = tasks.data;

  const data = useMemo(() => {
    if (!projectList || !taskList) return null;
    const today = new Date().toISOString().slice(0, 10);
    const open = taskList.filter((task) => task.status !== "done");
    const progress: ProjectProgress[] = projectList.map((project) => {
      const own = taskList.filter((task) => task.projectId === project.id);
      const done = own.filter((task) => task.status === "done").length;
      const percent = own.length ? Math.round((done / own.length) * 100) : 0;
      return { project, done, total: own.length, percent };
    });
    return {
      activeProjects: projectList.filter((project) => !project.archived).length,
      completedTasks: taskList.length - open.length,
      overdue: open.filter((task) => task.dueDate < today).length,
      progress,
      upcoming: open
        .filter((task) => task.dueDate >= today)
        .sort((a, b) => a.dueDate.localeCompare(b.dueDate))
        .slice(0, 5),
    };
  }, [projectList, taskList]);

  return {
    data,
    isLoading: projects.isLoading || tasks.isLoading,
    isError: projects.isError || tasks.isError,
  };
}
