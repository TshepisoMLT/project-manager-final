# Project Manager

A modern project management platform built with Next.js, TypeScript, Tailwind CSS, Zustand, and TanStack Query, hosted on Vercel. Supabase is planned but not connected yet.

## Getting started

```bash
npm install
npm run dev
```

## Scripts

- `npm run dev` – start the local development server
- `npm run build` – create a production build
- `npm run start` – run the production build
- `npm run lint` – verify the codebase with Next.js linting

## Current status

The UI is built and runs on sample data saved in the browser (no database, no real authentication):

- Login, register, and reset-password screens (visual only)
- Dashboard with project progress, overdue work, and upcoming deadlines
- Projects: create, edit, archive
- Kanban board: create, edit, delete, and move tasks
- Search across projects, tasks, and assignees
- Board filters, sorting, and overdue highlighting
- Pagination on projects, board columns, and search results

See `docs/ARCHITECTURE.md` for the structure and `docs/DEPLOYMENT.md` for hosting.

## Environment variables

None are required yet. Copy `.env.example` to `.env.local` when the Supabase layer is added.
