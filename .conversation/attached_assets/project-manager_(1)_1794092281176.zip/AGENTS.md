# AGENTS.md

Rules for all AI coding assistants working on this project.

These instructions apply to Copilot, Cursor, Claude Code, Cline, GPT, Aider, and any future coding agent.

---

# 1. Core Principles

- Do exactly what is requested.
- Never add features that were not requested.
- Never refactor unrelated code.
- Never introduce libraries without approval.
- Prefer simple solutions over clever solutions.
- Match existing project patterns.
- If requirements are unclear, stop and ask.

---

# 2. Planning Rules

For anything larger than a small fix:

1. Explain the change.
2. List affected files.
3. State assumptions.
4. Wait for approval.

Do not generate code until the plan is approved.

---

# 3. Scope Discipline

Allowed:

- Fix the requested issue.
- Add the requested feature.
- Update required documentation.

Not allowed:

- Reformat unrelated files.
- Rename existing files.
- Refactor unrelated components.
- Upgrade packages.
- Change configuration files unless requested.

---

# 4. Project Goals

This application is a lightweight project management platform.

Primary features:

- Authentication
- Projects
- Tasks
- Kanban Boards
- Team Collaboration
- Dashboard Analytics

If a proposed feature does not help those goals, do not add it.

---

# 5. Security Requirements

Never:

- Commit secrets
- Commit API keys
- Commit .env files
- Expose service-role keys
- Disable RLS policies
- Disable authentication

Always:

- Validate user input
- Use least privilege
- Enforce project permissions

---

# 6. Database Rules

All data lives in Supabase.

Source of truth:

- profiles
- projects
- project_members
- tasks

Business logic should be implemented through services.

UI components must never directly access Supabase.

---

# 7. Verification Requirements

Before declaring work complete:

- TypeScript passes
- Lint passes
- Build passes

Never claim something works unless it has been verified.

Use:

npm run lint

npm run build

---

# 8. Documentation

When changing:

- Database schema
- Authentication
- Folder structure
- Environment variables

Update docs immediately.

Relevant files:

- docs/PRD.md
- docs/ARCHITECTURE.md
- docs/DATABASE.md
- docs/DEPLOYMENT.md

---

# 9. Commit Messages

Use imperative mood.

Examples:

Add task creation form

Fix kanban drag issue

Update dashboard metrics

Do not use:

fixed stuff

changes

update

---

# 10. If Stuck

After two failed attempts:

- Stop
- Explain what was tried
- Explain what failed
- Ask for guidance
